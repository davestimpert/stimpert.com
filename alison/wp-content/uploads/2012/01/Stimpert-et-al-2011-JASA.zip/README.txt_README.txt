ARTICLE INFORMATION

Journal: 	Journal of the Acoustical Society of America

All Authors: 	Alison K. Stimpert, Whitlow W.L. Au, Susan E. Parks, Thomas Hurst, David N. Wiley

Title: 	Common humpback whale (Megaptera novaeangliae) sound types for passive acoustic monitoring


DEPOSIT INFORMATION

Description: 	Acoustic examples of sounds described in article.  

Total No. of Files: 	3

File Names: 	
README.TXT
MM1_Stimpert_etal_wop.wav
MM2_Stimpert_etal_grunts.wav

File captions:  
Multimedia file 1.  One representative "wop" sound, from tagged whale mn06_196a.  Sampling rate 64kHz.  
Multimedia file 2.  Representative "grunt" sounds, from tagged whale mn06_196a.  Grunts typically occurred in bouts of several units, or sounds.  Sampling rate 64kHz.  

Contact Information: 	
Alison K. Stimpert
stimpert@hawaii.edu

